<template>
  <div id="app">
    <div class="container">
      <Header :cart="cart" @update-search="updateSearch" @toggle-cart="toggleCart" />
      <HeroBanner />
      <ProductGrid :products="products" :searchTerm="searchTerm" @add-to-cart="addToCart" />
      <CartOverlay :cart="cart" :isOpen="isCartOpen" @close-cart="toggleCart" @remove-item="removeItem" />
      <Footer />
    </div>
  </div>
</template>

<script>
import Header from './components/Header.vue';
import HeroBanner from './components/HeroBanner.vue';
import ProductGrid from './components/ProductGrid.vue';
import Footer from './components/Footer.vue';
import CartOverlay from './components/CartOverlay.vue';

export default {
  name: 'App',
  components: {
    Header,
    HeroBanner,
    ProductGrid,
    Footer,
    CartOverlay,
  },
  data() {
    return {
      products: [
        { id: 1, name: 'Colorful Chair', image: 'https://picsum.photos/200/300', price: 59.99 },
        { id: 2, name: 'Rainbow Lamp', image: 'https://picsum.photos/200/301', price: 29.99 },
        { id: 3, name: 'Vibrant Table', image: 'https://picsum.photos/200/302', price: 89.99 },
        { id: 4, name: 'Artistic Mug', image: 'https://picsum.photos/200/303', price: 19.99 },
      ],
      cart: [],
      searchTerm: "",
      isCartOpen: false,
    };
  },
  methods: {
    addToCart(product) {
      this.cart.push(product);
    },
    updateSearch(term) {
      this.searchTerm = term;
    },
    toggleCart() {
      this.isCartOpen = !this.isCartOpen;
    },
    removeItem(index) {
      this.cart.splice(index, 1);
    },
  },
};
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  color: #2c3e50;
  display: flex;
  justify-content: center;
  padding: 20px;
}

.container {
  max-width: 1200px;
  width: 100%;
  background-color: #ffffff;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
  border-radius: 10px;
  padding: 20px;
}
</style>
