<template>
  <header class="header">
    <div class="logo">Store</div>
    <div class="search-bar">
      <input type="text" v-model="searchQuery" @input="$emit('update-search', searchQuery)" placeholder="Search for products..." />
      <button class="search-button">Search</button>
    </div>
    <nav class="nav-links">
      <a href="#">Home</a>
      <a href="#">Categories</a>
      <a href="#">Deals</a>
      <button @click="$emit('toggle-cart')" class="cart-button">Cart ({{ cart.length }})</button>
    </nav>
  </header>
</template>

<script>
export default {
  name: 'Header',
  props: ['cart'],
  data() {
    return {
      searchQuery: "",
    };
  },
};
</script>

<style scoped>
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #f39c12;
  padding: 20px;
  color: #fff;
}
.logo {
  font-size: 24px;
  font-weight: bold;
}
.search-bar {
  display: flex;
  align-items: center;
}
.search-bar input {
  padding: 10px;
  border: none;
  border-radius: 4px;
  width: 300px;
}
.search-button {
  margin-left: 10px;
  padding: 10px 20px;
  background-color: #2980b9;
  border: none;
  color: white;
  border-radius: 4px;
  cursor: pointer;
}
.search-button:hover {
  background-color: #1f6393;
}
.nav-links {
  display: flex;
  align-items: center;
}
.cart-button {
  margin-left: 20px;
  background: #27ae60;
  border: none;
  color: #fff;
  padding: 10px 15px;
  cursor: pointer;
  border-radius: 5px;
}
.cart-button:hover {
  background: #1e8449;
}
</style>
