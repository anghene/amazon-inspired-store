<template>
  <footer class="footer">
    <p>&copy; 2024 Colorful Store. All rights reserved.</p>
  </footer>
</template>

<script>
export default {
  name: 'Footer',
};
</script>

<style scoped>
.footer {
  background-color: #34495e;
  color: #fff;
  padding: 20px;
  text-align: center;
}
</style>